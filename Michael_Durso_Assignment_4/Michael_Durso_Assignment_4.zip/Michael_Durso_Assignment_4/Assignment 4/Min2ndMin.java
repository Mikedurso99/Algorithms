
public class Min2ndMin {
	int min;
	int min2nd;
}
